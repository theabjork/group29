//
//  newclass.hpp
//  blabla
//
//  Created by Katrin Arnardottir on 30/11/2017.
//  Copyright © 2017 Katrin Arnardottir. All rights reserved.
//

#ifndef newclass_hpp
#define newclass_hpp
#include "topping.hpp"
#include <stdio.h>
#include <iostream>
using namespace std;

class Pizza{
    
private:
    //Topping* _topping;
    //int _topping_count;
    
public:
    Pizza();
    //Pizza(int number_of_toppings, char crust, int size);
    //void addTopping(Topping topping);
    
    //~Pizza();
    
    
    
};




#endif


#ifndef MAINMENU_H
#define MAINMENU_H
#include <iostream>
#include <string>
#include <fstream>


using namespace std;

class Menu{
public:
    Menu();
    void welcomeMessage();
    void options();
    void validate_user_input(char input);
    //Pizza create_pizza(int number_of_toppings);
    
    
private:
    //SaleService make_order;
    
    
    
};

#endif

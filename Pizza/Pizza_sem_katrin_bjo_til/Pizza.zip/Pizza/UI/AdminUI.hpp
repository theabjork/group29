//
//  AdminUI.hpp
//  Pizza
//
//  Created by Katrin Arnardottir on 06/12/2017.
//  Copyright © 2017 Katrin Arnardottir. All rights reserved.
//

#ifndef AdminUI_hpp
#define AdminUI_hpp

#include <fstream>
using namespace std;

#include <stdio.h>

class Admin{
    
private:
    
    
public:
    void the_menu();


};

#endif /* AdminUI_hpp */

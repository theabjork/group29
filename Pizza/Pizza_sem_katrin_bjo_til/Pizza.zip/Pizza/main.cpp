#include <iostream>
#include <string>
#include "SalesUI.hpp"
#include "mainUI.hpp"
#include <fstream>
#include "AdminUI.hpp"
using namespace std;
    
int main(){
    Menu message;
    MainUI userinterface;

    userinterface.startUI();
    
    
        
    return 0;
}

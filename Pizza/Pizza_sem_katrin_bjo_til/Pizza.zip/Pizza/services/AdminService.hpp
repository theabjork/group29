//
//  AdminService.hpp
//  Pizza
//
//  Created by Katrin Arnardottir on 06/12/2017.
//  Copyright © 2017 Katrin Arnardottir. All rights reserved.
//

#ifndef AdminService_hpp
#define AdminService_hpp

#include <stdio.h>



#endif /* AdminService_hpp */

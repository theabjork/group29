//
//  SaleService.hpp
//  Pizza
//
//  Created by Katrin Arnardottir on 06/12/2017.
//  Copyright © 2017 Katrin Arnardottir. All rights reserved.
//

#ifndef SaleService_hpp
#define SaleService_hpp
#include "pizza.hpp"
using namespace std;
#include <stdio.h>

class SaleService{
private:
    
public:
    SaleService();
    //void add_pizza(const Pizza& pizza);
    
    
    
    
};




#endif

//
//  SaleService.cpp
//  Pizza
//
//  Created by Katrin Arnardottir on 06/12/2017.
//  Copyright © 2017 Katrin Arnardottir. All rights reserved.
//
#include "SaleService.hpp"
using namespace std;

//void SaleService:: add_pizza(const Pizza& pizza){
    
//}



//
//  AdminRepository.hpp
//  Pizza
//
//  Created by Katrin Arnardottir on 06/12/2017.
//  Copyright © 2017 Katrin Arnardottir. All rights reserved.
//

#ifndef AdminRepository_hpp
#define AdminRepository_hpp

#include <stdio.h>
#include <string>
#include <fstream>

class AdminRepo{
private:
    
public:
    void the_menu();
    
    
    
    
};






#endif /* AdminRepository_hpp */
